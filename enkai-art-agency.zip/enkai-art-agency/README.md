# Enkai Art Agency

Website portfolio nghệ thuật **mềm mại – dịu dàng – sang trọng** của **Tran Quang Trung**.

Chạy trên **GitHub Pages** (miễn phí).

---

## Cấu trúc thư mục (CỰC KỲ QUAN TRỌNG)

```
enkai-art-agency/
├── index.html              ← Trang chính
├── css/
│   └── style.css           ← Giao diện
├── js/
│   └── main.js             ← Logic gallery + xem chi tiết
├── data/
│   └── works.json          ← Danh sách tất cả tác phẩm
├── assets/
│   ├── images/             ← Đặt ảnh của bạn vào đây
│   └── videos/             ← Đặt video của bạn vào đây
└── README.md
```

**Khi upload lên GitHub phải giữ nguyên cấu trúc thư mục này.**  
Không được bỏ hết file ra ngoài cùng (root).

---

## Cách thêm ảnh / video mới

### Cách dễ nhất (dùng link ảnh):

1. Đưa ảnh lên https://postimages.org → copy **Direct link**
2. Mở file `data/works.json`
3. Thêm mục mới:

```json
{
  "id": 5,
  "title": "Tên tác phẩm của bạn",
  "type": "image",
  "src": "https://i.postimg.cc/xxxxx/anh-cua-ban.jpg",
  "description": "Mô tả ngắn về tác phẩm này...",
  "date": "2026-07-25"
}
```

### Cách upload trực tiếp lên GitHub:

1. Add file → Upload files
2. Ở ô tên file ghi: `assets/images/ten-anh.jpg`
3. Sau đó sửa `works.json` với `src: "assets/images/ten-anh.jpg"`

---

## Đổi email liên hệ

Mở `index.html` → tìm `contact@enkai.art` → sửa thành email của bạn.

---

## Gắn tên miền riêng

1. Tạo file tên `CNAME` (không có đuôi)
2. Bên trong chỉ viết 1 dòng tên miền của bạn, ví dụ:
   ```
   enkai.art
   ```
3. Cấu hình DNS trỏ về GitHub Pages (A record hoặc CNAME).

---

Chúc bạn xây dựng Enkai Art Agency thật đẹp!
